import csv
from os import kill


class Analysis:
    # define class vars
    def __init__(self):
        # define arrays to store data
        # these are written to during csv parsing
        self.qualtricsIdArr = []
        self.webform1IdArr = []
        self.webform2IdArr = []
        self.msBot1IdArr = []
        self.msBot2IdArr = []
        self.gptBot1IdArr = []
        self.gptBot2IdArr = []

        # define sets to store data
        # these are generated from the arrays
        # sets do not allow duplicates and allow for O(1) lookup compared to O(n) for arrays
        self.qualtricsIdSet = set()
        self.webform1IdSet = set()
        self.webform2IdSet = set()
        self.msBot1IdSet = set()
        self.msBot2IdSet = set()
        self.gptBot1IdSet = set()
        self.gptBot2IdSet = set()

        # define dict to store mapping of qualtrics ids to conditions
        # general example -> {'qualtricsId': 'condition'}
        # specific example -> {'R_1F2kMSTy7P82ZUB', 'R_u3Wp1DEPP8eV0BP', ... <more instances>}
        self.qualtricsIdConditionMap = {}

    def getIds(self):
        # read ids from csv file in this directory
        # check header row and append all UUIDs to approriate arrays
        fileName = "spreadsheet.csv"
        try:
            with open(fileName, "r", newline="", encoding="utf-8") as file:
                reader = csv.DictReader(file, delimiter="\t")
                for row in reader:
                    self.qualtricsIdArr.append(row["qualtricsIds"])
                    self.webform1IdArr.append(row["webform1Ids"])
                    self.webform2IdArr.append(row["webform2Ids"])
                    self.msBot1IdArr.append(row["msBot1Ids"])
                    self.msBot2IdArr.append(row["msBot2Ids"])
                    self.gptBot1IdArr.append(row["gptBot1Ids"])
                    self.gptBot2IdArr.append(row["gptBot2Ids"])

            # if no errors during csv parsing process
            print("Data loaded successfully.")

        # if errors during csv parsing process
        except Exception as error:
            print(f"Error reading CSV file: {error}")

    def genSetsFromArrs(self):
        # build sets from arrays
        self.qualtricsIdSet = set(self.qualtricsIdArr)
        self.webform1IdSet = set(self.webform1IdArr)
        self.webform2IdSet = set(self.webform2IdArr)
        self.msBot1IdSet = set(self.msBot1IdArr)
        self.msBot2IdSet = set(self.msBot2IdArr)
        self.gptBot1IdSet = set(self.gptBot1IdArr)
        self.gptBot2IdSet = set(self.gptBot2IdArr)

    def mapConditions(self):
        # map conditions to qualtrics ids based on set membership
        for participant in self.qualtricsIdSet:
            if participant in self.webform1IdSet:
                self.qualtricsIdConditionMap[participant] = "Webform1"
            elif participant in self.webform2IdSet:
                self.qualtricsIdConditionMap[participant] = "Webform2"
            elif participant in self.msBot1IdSet:
                self.qualtricsIdConditionMap[participant] = "MSBot1"
            elif participant in self.msBot2IdSet:
                self.qualtricsIdConditionMap[participant] = "MSBot2"
            elif participant in self.gptBot1IdSet:
                self.qualtricsIdConditionMap[participant] = "GPTBot1"
            elif participant in self.gptBot2IdSet:
                self.qualtricsIdConditionMap[participant] = "GPTBot2"
            else:
                self.qualtricsIdConditionMap[
                    participant
                ] = "Error-participant not found in any condition"

    # check to see if there are duplicates in the data sets
    # this can be done by comapring the length of the lists (which allow duplicates) to the length of the sets (which do not allow duplicates)
    def checkDuplicates(self):
        errors = False
        setsWithErrors = []
        if len(self.qualtricsIdArr) != len(self.qualtricsIdSet):
            errors = True
            setsWithErrors.append("Qualtrics")
        if len(self.webform1IdArr) != len(self.webform1IdSet):
            errors = True
            setsWithErrors.append("Webform1")
        if len(self.webform2IdArr) != len(self.webform2IdSet):
            errors = True
            setsWithErrors.append("Webform2")
        if len(self.msBot1IdArr) != len(self.msBot1IdSet):
            errors = True
            setsWithErrors.append("MSBot1")
        if len(self.msBot2IdArr) != len(self.msBot2IdSet):
            errors = True
            setsWithErrors.append("MSBot2")
        if len(self.gptBot1IdArr) != len(self.gptBot1IdSet):
            errors = True
            setsWithErrors.append("GPTBot1")
        if len(self.gptBot2IdArr) != len(self.gptBot2IdSet):
            errors = True
            setsWithErrors.append("GPTBot2")

        if errors:
            for set in setsWithErrors:
                print(f"Error: {set} has duplicates.")
            raise Exception("Duplicate IDs found.")


if __name__ == "__main__":
    test = Analysis()
    test.getIds()
    test.genSetsFromArrs()
    test.checkDuplicates()
    test.mapConditions()
